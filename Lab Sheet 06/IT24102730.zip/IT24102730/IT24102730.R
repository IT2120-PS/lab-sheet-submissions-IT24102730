setwd("C:\\Users\\USER\\Desktop\\IT24102730")

#Question 1

#Binomial Distribution
pbinom(46, 50, 0.85, lower.tail = FALSE)

#Question 02

#Let X - Number of calls received in a hour
#Poisson Distribution
dpois(15, 12)